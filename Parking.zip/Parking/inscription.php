<?php session_start();
$connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
//  include 'connexion.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <title> register</title>
</head>
<?include 'header.php';?>
<body>
<nav>
        <ul class="nav navbar-nav">
            <li><a href="./index.php"title ="home">home </a></li>
            <li class="active"><a href="#" title="inscription"> inscription</a></li>
            <li><a href="connecter.php" title="connexion">connexion</a></li>
            <li><a href="contact.php" title="contact">contact</a></li>
        </ul>
    
    </nav>
<h2>Créer votre compte gratuitement et reservez votre place</h2>
<table>
<form  action="inscription.php" method="post">
<tr>
    
<td><label for ="nom">NOM:</label></td>
<td><input type ="text" name="nom"  id="nom" placeholder="Your Name" required/></td>
</tr>
<tr>
<td><label for ="Prenom">Prenom:</label></td>
<td><input type ="text" name="prenom"  id="prenom" placeholder=" Votre Prenom" required/></td>
</tr>
<tr>
<td><label for ="mail">Mail:</label></td>
<td><input type ="text" name="mail"  id="mail" placeholder="Your e-mail" required/></td>
</tr>
<tr>
<td><label for ="mdp">Mot de pass:</label></td>
<td><input type ="password" name="mdp"  id="mdp" placeholder="Your Password" required/>
</td>
</tr>
<tr>
<td><input type="submit" value="s'inscrire"/></td>
</tr>

</form>
</table>
</body>

</html>
<?php if (isset($_POST['nom'])) {
    
    
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $mail = $_POST['mail'];
   $mdp= $_POST['mdp'];

   $requete=$connexion->prepare('SELECT * FROM utilisateur where mail = ? ');
   $requete->execute(array($mail));

   if (!$resultat = $requete->fetch()) {
       $requete2=$bdd->prepare('INSERT INTO utilisateur(nom,prenom,mail,mdp) VALUES(:nom, :prenom, :mdp, :mail)');
   
       $array = array(
           'nom' => $nom,
           'prenom'=>$prenom,
           'mail' => $mail,
           'mdp' => $mdp);
       $requete2->execute($array);
   }   
      
    }

?>
<?php include 'footer.php';?>