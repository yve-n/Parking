<?php 
	session_start();
?>
<!DOCTYPE html>
<html>
		<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
		<link rel="stylesheet" href="./css/style.css ">
	<title>Site de reservation</title>
	</head>
<?php include 'header.php';?>
	<?php include 'menu.php';?>

	<body>
		<section>
			<h2> Bienvenue sur Easy Park  site de réservations de place de parking moderne et pratique </h2><br/>
		</section>
		<img src="./asset/park.jpg" alt="accueil" />
		<p>
			<br />
		</p>
	</body>
    <?php include'footer.php'; ?>
</html>
