<?php session_start();?>

<!DOCTYPE html>
<html>
       <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="./css/style.css" />
    <title>Site de reservation</title>

    </head>

    <?php include 'menu.php';
    $connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
    //  include 'connexion.php'; ?>
    <body>
        <h2> Mot de passe oublié ?</h2>
        <form method="post" action="mdp-perdu.php">
            <p>
                <h3> Entrez vos coordonnées</h3><br />
                <label>Votre Adresse Mail</label> : <input type="mail" name="mail" placeholder="Ex : dupont.pierre@gmail.com" maxlength="50" /><br /><br />
                <label>Nouveau mot de passe</label> : <input type="mdp" name="mdp" maxlength="60" /><br /><br />
                <input type="submit" value="Valider" />
            </p>
        </form>
        <?php 
		$mail = $_POST['mail'];
		$mdp = $_POST['mdp']; 
		$trouve = false;

		$requete = $bdd->query('SELECT * FROM utilisateur');
		while($donnees = $requete->fetch())
		{
			if($donnees['Mail'] == $Mail )
			{
				$requete2 = $bdd->prepare('UPDATE utilisateur SET mdp = :mdp WHERE mail = :mail ');
				$requete2->execute(array(
					'mail'=> $mail,
					'mdp'=> $mdp));

				$trouve = true;

				echo 'Le mot de passe a été changé. <a href="connecter.php">Retour à la page de connexion</a>';
			}
		}

		if($trouve == false)
		{
			echo'Erreur de saisie.<a href="mdp-perdu.php">Resaisir</a>ou <a href="index.php">Retour à la page d\'accueil</a>';
		}

		?>
    </body>
    <?php include("footer.php"); ?>
</html>