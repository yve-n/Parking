<?php session_start();
$connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
?>
<!DOCTYPE html>
<html>
       <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
        <link rel="stylesheet" href="./css/style.css" />
    <title>Site de reservation</title>
    
    </head>
    <?php include 'header.php';?>
    <body>
        
    <nav>
        <ul class="nav navbar-nav">
            <li><a href="./index.php"title ="home">home </a></li>
            <li><a href="inscription.php" title="inscription"> inscription</a></li>
            <li class="active"><a href="#" title="connexion">connexion</a></li>
            <li><a href="contact.php" title="contact">contact</a></li>
        </ul>
    
    </nav>
        
        <form method="post" action="connecter.php">
            <p>
                
                <label>Identifiant</label> : <input type="text" name="mail" placeholder="Ex : adresse mail" maxlength="50" /><br /><br />
                <label>Mot de Passe</label> : <input type="password" name="mdp" maxlength="60" /><br /><br />
                <input type="submit" value=" Je me connecte" />
                 <a href="mdp-perdu.php">Mot de passe perdu ?</a>
            </p>
        </form>
    </body>
    
</html>

 <!-- 
// $connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
// $mail=$_POST['mail'];
// $mdp=$_POST['mdp'];
// $trouve = false;

//         $requete = $connexion->prepare('SELECT * FROM UTILISATEUR');
//         $requete->execute();
        
		// while($donnees = $requete->fetch())
		// {
		// 	if($donnees['mail'] == $mail && $donnees['mdp'] == $mdp) 
		// 	{
		// 		$_SESSION['numuser'] = $donnees['numuser'];
		// 		$_SESSION['nom'] = $donnees['nom'];
		// 		$_SESSION['prenom'] = $donnees['prenom'];
		// 		$trouve = true;
		// 	}
		// }
	


		// if($trouve == true) 
		// {
		// 	echo 'Votre connexion a reussi. Aller à <a href="index.php">l\'accueil</a>';
		// }


		// if($trouve == false)
		// {
			// echo' Erreur de saisie ou compte non existant, <a href="inscription.php">s\'inscrire</a>';
		// }
		
// ?>
 //php include'footer.php'; ?>  

<?php 
//inclusion de fichier de configuration
$connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
	
//on verifie si le formulaire a été envoyé
if(isset($_POST['submit'])){
    //la variable erreur vaut null par défaut
    $erreur = null;
    //on convertit chaque champ en variable avec la fonction extract()
    extract($_POST);
    
    //on verifie les champs vides
    if(empty($mail) || empty($mdp)){
        $erreur = '<p class = "alert alert-danger">Veuillez remplir tous les champs</p>';
    }
    
    //on verifie si le pseudo existe déja
    $requete = mysql_query("SELECT * FROM utilisateur WHERE mail = '$mail'") or die('Erreur de la requête SQL');
    $total = mysql_num_rows($requete);
    if($total != 1){
        //ce membre n'existe pas
        $erreur = '<p class = "alert alert-danger">Ce pseudo n\'existe pas dans notre base de données</p>';
    }
    else{
        /*
            on verifie si le mot de passe est correct
            tout d'abord pour comparer le mot de passe avec celui dans la table 
            il faut le crypter avant en utilisant la fonction md5() 
        */
        $mdp = md5($mdp);  //utiliser password_hash
        //recuperation des données dans la table de l'utilisateur
        $resultat = mysql_fetch_array($requete);
        
        if($resultat['mdp'] !== $mdp){
            //le mot de passe est incorrect
            $erreur = '<p class = "alert alert-danger">Votre mot de passe est incorrect</p>';
        }
        else{
            //tout est bon on enregistre les données de l'utilisateur en session
            session_start();
            $_SESSION['mail'] = $mail;
            $_SESSION['numuser'] = $resultat['numuser'];
            //on le redirige sur la page d'accueil
            header('location:index.php');
        }
        
    }		
}
?>



  







