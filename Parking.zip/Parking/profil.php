<?php
	//inclusion de fichier de configuration
	$connexion = new PDO('mysql:host=localhost;dbname=parking;charset=utf8', 'root', '');
	if(!isset($_SESSION['mail']) || !isset($_SESSION['mdp'])){
		//l'utilisateur n'est pas connecté on le redirige sur la page de connexion
		header('location:connecter.php');
	}
	
	//on verifie si l'id de existe 
	if(!isset($_GET['mail'])){
		//l'id de l'utilisateur n'existe pas on le redirige sur la page des membres
		header('location:index.php');
	}
	else{
		$id = mysql_escape_string($_GET['mail']);
		$requete = mysql_query("SELECT * FROM utilisateur WHERE mail = '$mail' && mdp='$mdp ") or die('Erreur de la requête SQL');
		//les donnees sous forme de tableau
		$donnees = mysql_fetch_array($requete);
		if(empty($donnees)){
			//Cet utilisateur n'existe pas on le redirige sur la page des membres
			header('location:index.php');
		}
	}
?>
<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Espace utilisateur</title>

	<!-- CSS de Bootstrap -->
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	 <!-- Notre style CSS  -->
	<link href="bootstrap/css/style.css" rel="stylesheet">
	
  </head>
  <body>
	<div class = "container">
		<br />
		<div class "row">
			<div class = "col-lg-offset-3 col-lg-6 col-lg-offset-3 well">
				<h2>Espace membre de <?php echo $donnees['mail'];?></h2>
                <p>Bienvenue dans votre compte <b><?php echo $donnees['mail'];?></b> voici vos informations</p>
				<p>Nom : <b><?php echo $donnees['nom'];?></b></p>
				<p>Prénom : <b><?php echo $donnees['prenom'];?></b></p>
				
				<p>
					 <a class = "btn btn-sm btn-primary" href = "membres.php"><i class = "glyphicon glyphicon-th-list"></i> Liste des membres</a>
					 <a class = "btn btn-sm btn-default" href = "index.php"> &laquo;  <i class = "glyphicon glyphicon-user"></i> Votre compte</a>
				 </p>
			</div>
		</div>
	</div>
	<!-- Bibliothèque JavaScript jquery -->
	<script src="bootstrap/js/jquery.min.js"></script>
	
	<!--  JavaScript de Bootstrap -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>