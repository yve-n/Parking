<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>site de reservation </title>
</head>
<body>
    <nav>
        <ul class="nav navbar-nav">
            <li class="active"><a href="index.php"title ="home">home </a></li>
            <li><a href="inscription.php" title="inscription"> inscription</a></li>
            <li><a href="connecter.php" title="connexion">connexion</a></li>
            <li><a href="contact.php" title="contact">contact</a></li>
        </ul>
    
    </nav>
</body>
</html>