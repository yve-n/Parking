<?php
	session_start();
?>
<!DOCTYPE html>
<html>
		<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="moncss.css" />
	<title>Site de reservation</title>
	
	</head>

	<?php include 'menu.php';
		  include 'connexion.php';  ?>

	<body>
		<h2> Réservation </h2><br/>

		<?php
		$numuser = $_SESSION['numuser'];
		$dated = $_POST['dated'];
		$datef = $_POST['datef'];
		//$statut = 0;


			$req = $bdd->prepare('INSERT INTO reserver(numuser, date_debut_reserv, date_fin_reserv) VALUES (:numuser, :date_debut_reserv, :date_fin_reserv)');
			$req -> execute(array(
				'id_uti'=> $id_uti,
				'date_debut_reserv'=> $dated,
				'date_fin_reserv'=> $datef));
				//'statut' => $statut));

			echo 'Votre réservation a bien été prise en compte. <a href="index.php"> Retour à l\'accueil </a>';

		?>
		</p>
	</body>
    <?php include("footer.php"); ?>
</html>
